import 'package:MMLMobile/databasemodels/RowSources_30_2.dart';
import 'package:MMLMobile/databasemodels/RowSources_RS_12_2.dart';
import 'package:MMLMobile/databasemodels/RowSources_RS_1_10_2.dart';
import 'package:MMLMobile/databasemodels/RowSources_RS_29_41_15_6.dart';
import 'package:MMLMobile/models/RequestKeys.dart';
import 'package:MMLMobile/models/NavigationObject.dart';
import 'package:MMLMobile/models/PageDirectionObject.dart';
import 'package:MMLMobile/models/ResponseBody.dart';
import 'package:MMLMobile/models/RowSources.dart';
import 'package:MMLMobile/models/organization/PI_33_PRI_130_PRCI_688_Children.dart';
import 'package:MMLMobile/models/organization/PI_33_PRI_130_PRCI_688_Parent.dart';
import 'package:MMLMobile/models/organization/PI_33_PRI_130_PRCI_688_TreePath.dart';

const String APP_NAME = "MML";
const String BASE_URL =
    "http://mymaintenancelibraryservicesit.azurewebsites.net/api/Account/Login";
const String BASE_LOGIN = "/api/Account/Login";
const String GET_LOGIN_DETAILS = "/api/Account/GetLoginJson";
const String GET_LOGOUT_DETAILS = "/api/Account/GetLogoutJson";
const String SEND_ERROR_CODE = "/api/Account/SendErrorCode";
const String GET_FORGOT_DETAILS = "/api/Account/SendActivateMail";
const String POST_REFERSH = "/api/Account/NodeClick";
const String GET_SAS_TOKEN = "/api/Equipment/GetSasToken?Container=";

ResponseBody responseBody;

List<RowSources_RS_12_2> rowSource_RS_12_2;
List<RowSources_RS_1_10_2> rowSource_RS_1_10_2;
List<RowSources_RS_29_41_15_6> rowSource_RS_29_41_15_6;
List<RowSources_RS_30_2> rowSource_Rs_30_2;

//RecentTab Items
NavigationObject recentItemsText;
NavigationObject recentItemsImage;
String refreshTime;
String sasToken;
List<PageDirectionObject> recentItems;

List<PI_33_PRI_130_PRCI_688_Children> pi_33_PRI_130_PRCI_688_Children;

PI_33_PRI_130_PRCI_688_Parent pi_33_PRI_130_PRCI_688_Parent;

List<PI_33_PRI_130_PRCI_688_TreePath> pi_33_PRI_130_PRCI_688_TreePath;

RequestKeys organization_PRCI_772_NodeKey;

//Settings Items
NavigationObject settingItemsText;
NavigationObject settingItemsImage;
List<PageDirectionObject> settingItems;

//Things Items
List<PageDirectionObject> thingsItems;

//Users Items
List<PageDirectionObject> usersItems;

//Locations Items
List<PageDirectionObject> locationsItems;

//Places Items
List<PageDirectionObject> placesItems;

//Companies Items
List<PageDirectionObject> companiesItems;

//Account Items
List<PageDirectionObject> accountItems;

//back button events track
int backPI;
int backPRI;

int maximumCacheCountTreeView = 20;

// List<PI_33_PRCI_688_Children_Object> pi_33_PRCI_688_Children = [];
//
// PageDirectionObject pi_33_PRCI_688_Parent;
//
// List pi_33_PRCI_688_TreePath;
// RequestKeys pi_33_PRCI_772;

void initialize() {
  responseBody = null;

  rowSource_RS_12_2 = [];
  rowSource_RS_1_10_2 = [];
  rowSource_RS_29_41_15_6 = [];
  rowSource_Rs_30_2 = [];

//RecentTab Items
  recentItemsText = null;
  recentItemsImage = null;
  refreshTime = "";
  sasToken = "";
  recentItems = [];

  pi_33_PRI_130_PRCI_688_Children = [];

  pi_33_PRI_130_PRCI_688_Parent;

  pi_33_PRI_130_PRCI_688_TreePath = [];
  organization_PRCI_772_NodeKey = null;

//Settings Items
  settingItemsText = null;
  settingItemsImage = null;
  settingItems = [];

//Things Items
  thingsItems = [];

//Users Items
  usersItems = [];

//Locations Items
  locationsItems = [];

//Places Items
  placesItems = [];

//Companies Items
  companiesItems = [];

//Account Items
  accountItems = [];
}
